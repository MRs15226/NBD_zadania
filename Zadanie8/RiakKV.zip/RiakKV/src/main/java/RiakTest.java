import com.basho.riak.client.api.RiakClient;
import com.basho.riak.client.api.commands.kv.DeleteValue;
import com.basho.riak.client.api.commands.kv.FetchValue;
import com.basho.riak.client.api.commands.kv.StoreValue;
import com.basho.riak.client.core.RiakCluster;
import com.basho.riak.client.core.RiakNode;
import com.basho.riak.client.core.query.Location;
import com.basho.riak.client.core.query.Namespace;

import java.net.UnknownHostException;

public class RiakTest {

    private static RiakCluster setUpCluster() throws UnknownHostException {

        RiakNode node = new RiakNode.Builder()
                .withRemoteAddress("192.168.99.100")
                .withRemotePort(8087)
                .build();


        RiakCluster cluster = new RiakCluster.Builder(node)
                .build();

        cluster.start();

        return cluster;
    }

    public static void main( String[] args ) {
        try {

            RiakCluster cluster = setUpCluster();
            RiakClient client = new RiakClient(cluster);

            Student student = new Student();

            student.setName("Maciej");
            student.setSurname("Rogowski");
            student.setIndexNumber("s15226");

            Namespace studentBucket = new Namespace("students");
            Location studentLocation = new Location(studentBucket, "s15226");

            System.out.println("Wstawienie rekordu");
            StoreValue storeStudentOp = new StoreValue.Builder(student)
                    .withLocation(studentLocation)
                    .build();
            client.execute(storeStudentOp);

            System.out.println("Wyszukanie rekordu");
            FetchValue fetchStudent = new FetchValue.Builder(studentLocation)
                    .build();
            Student fetchedStudent = client.execute(fetchStudent).getValue(Student.class);

            System.out.println(fetchedStudent);

            fetchedStudent.setName("Daniel");

            System.out.println("Aktulizacja rekordu");
            StoreValue updateStudent = new StoreValue.Builder(fetchedStudent)
                    .withLocation(studentLocation)
                    .build();

            client.execute(updateStudent);

            System.out.println("Ponowne wyszukanie rekordu - po aktualizacji");
            fetchedStudent = client.execute(fetchStudent).getValue(Student.class);
            System.out.println(fetchedStudent);

            System.out.println("Usunięcie rekordu");
            DeleteValue deleteOp = new DeleteValue.Builder(studentLocation)
                    .build();
            client.execute(deleteOp);

            System.out.println("Wyszukanie rekordu");
            fetchedStudent = client.execute(fetchStudent).getValue(Student.class);
            System.out.println(fetchedStudent);

            cluster.shutdown();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}